function ber = ber(dataIn,dataOut)
 
[~,ber] = biterr(dataIn,dataOut);

 end